export const MESSAGE = 'MESSAGE';
export const ERROR = 'ERROR';
export const JOIN = 'JOIN';
export const LEAVE = 'LEAVE';
