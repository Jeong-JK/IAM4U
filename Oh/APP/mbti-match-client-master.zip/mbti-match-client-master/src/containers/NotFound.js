import React from 'react';

const NotFound = () => {
  return <div>페이지를 찾지 못하였습니다.</div>;
};

export default NotFound;
